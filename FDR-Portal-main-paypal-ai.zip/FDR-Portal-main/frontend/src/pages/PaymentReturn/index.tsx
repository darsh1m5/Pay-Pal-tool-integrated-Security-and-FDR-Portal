import { useEffect, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { CheckCircle2, XCircle } from 'lucide-react';
import { ApiError, api } from '@/lib/api';
import { inr } from '@/lib/format';
import { Button } from '@/components/ui/button';
import type { PaymentItem } from '@/lib/types';

type State = { phase: 'working' } | { phase: 'done'; payment: PaymentItem } | { phase: 'error'; message: string };

/** PayPal sends the payer back here with `?token=<order id>`; we capture the approved order. */
export default function PaymentReturnPage() {
  const [params] = useSearchParams();
  const orderId = params.get('token');
  const queryClient = useQueryClient();
  const [state, setState] = useState<State>({ phase: 'working' });
  const started = useRef(false);

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    if (!orderId) {
      setState({ phase: 'error', message: 'PayPal did not return an order reference.' });
      return;
    }
    api
      .post<PaymentItem>('/payments/shortfall/capture', { order_id: orderId })
      .then((payment) => {
        setState({ phase: 'done', payment });
        queryClient.invalidateQueries({ queryKey: ['payments'] });
        queryClient.invalidateQueries({ queryKey: ['dashboard'] });
      })
      .catch((err) =>
        setState({ phase: 'error', message: err instanceof ApiError ? err.detail : 'Could not confirm the payment.' }),
      );
  }, [orderId, queryClient]);

  return (
    <div className="mx-auto mt-16 max-w-md rounded-lg border border-[var(--line)] bg-white p-6 text-center">
      {state.phase === 'working' && (
        <>
          <div className="mx-auto mb-3 h-6 w-6 animate-spin rounded-full border-2 border-[var(--primary)] border-t-transparent" />
          <p className="text-sm text-[var(--ink-2)]">Confirming your PayPal payment…</p>
        </>
      )}
      {state.phase === 'done' && (
        <>
          <CheckCircle2 className="mx-auto mb-3 h-8 w-8 text-[var(--ok)]" />
          <h1 className="text-base font-semibold text-[var(--ink)]">Payment received</h1>
          <p className="mt-2 text-xs text-[var(--ink-3)]">
            {inr(state.payment.amount_inr)} recorded against {state.payment.institution_name}. PayPal capture{' '}
            <span className="font-mono">{state.payment.paypal_capture_id}</span>. This payment is now part of the
            audit trail.
          </p>
        </>
      )}
      {state.phase === 'error' && (
        <>
          <XCircle className="mx-auto mb-3 h-8 w-8 text-[var(--risk)]" />
          <h1 className="text-base font-semibold text-[var(--ink)]">Payment not completed</h1>
          <p className="mt-2 text-xs text-[var(--ink-3)]">{state.message}</p>
        </>
      )}
      {state.phase !== 'working' && (
        <Button asChild size="sm" className="mt-5">
          <Link to="/">Back to home</Link>
        </Button>
      )}
    </div>
  );
}
