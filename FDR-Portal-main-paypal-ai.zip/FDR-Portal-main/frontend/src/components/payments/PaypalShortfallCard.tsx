import { useMutation, useQuery } from '@tanstack/react-query';
import { Wallet } from 'lucide-react';
import { toast } from 'sonner';
import { ApiError, api } from '@/lib/api';
import { formatDateTime, inr } from '@/lib/format';
import { Button } from '@/components/ui/button';
import type { PaymentItem, PaymentOrder, PaypalConfig, ShortfallSummary } from '@/lib/types';

const money = (value: number, currency: string) =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(value);

/**
 * Shows an institution's deposit shortfall and lets the institution pay it through the PayPal sandbox.
 * The amount is always computed by the server; this component only displays it.
 */
export function PaypalShortfallCard() {
  const { data: config } = useQuery<PaypalConfig>({
    queryKey: ['payments', 'config'],
    queryFn: () => api.get<PaypalConfig>('/payments/config'),
  });
  const { data: summary } = useQuery<ShortfallSummary>({
    queryKey: ['payments', 'shortfall'],
    queryFn: () => api.get<ShortfallSummary>('/payments/shortfall'),
  });
  const { data: history } = useQuery<PaymentItem[]>({
    queryKey: ['payments', 'list', 'shortfall'],
    queryFn: () => api.get<PaymentItem[]>('/payments'),
  });

  const startPayment = useMutation({
    mutationFn: () => api.post<PaymentOrder>('/payments/shortfall/order', {}),
    onSuccess: (order) => {
      window.location.href = order.approve_url; // PayPal sandbox checkout; it returns to /payments/return
    },
    onError: (err) => toast.error(err instanceof ApiError ? err.detail : 'Could not start the PayPal payment'),
  });

  const topups = (history ?? []).filter((p) => p.kind === 'shortfall_topup' && p.status === 'completed');
  if (!summary || (summary.shortfall <= 0 && topups.length === 0)) return null;

  const currency = summary.currency;
  const outstanding = summary.outstanding_inr;

  return (
    <div className="rounded-lg border border-[var(--line)] bg-white p-4" data-testid="paypal-shortfall-card">
      <div className="flex items-center justify-between gap-3 border-b border-[var(--line)] pb-3">
        <div className="flex items-center gap-2">
          <Wallet className="h-4 w-4 text-[var(--ink-2)]" />
          <h2 className="text-sm font-semibold text-[var(--ink)]">Security deposit shortfall</h2>
        </div>
        <span className="rounded-full bg-[var(--info-bg)] px-2 py-0.5 text-[10px] font-medium text-[var(--info)]">
          PayPal sandbox
        </span>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-3 text-xs sm:grid-cols-4">
        <div>
          <div className="text-[var(--ink-3)]">Required</div>
          <div className="font-mono text-sm font-semibold">{inr(summary.required_deposit)}</div>
        </div>
        <div>
          <div className="text-[var(--ink-3)]">Held in register</div>
          <div className="font-mono text-sm font-semibold">{inr(summary.held)}</div>
        </div>
        <div>
          <div className="text-[var(--ink-3)]">Paid via PayPal</div>
          <div className="font-mono text-sm font-semibold text-[var(--ok)]">{inr(summary.paid_via_paypal_inr)}</div>
        </div>
        <div>
          <div className="text-[var(--ink-3)]">Outstanding</div>
          <div
            className={`font-mono text-sm font-semibold ${outstanding > 0 ? 'text-[var(--risk)]' : 'text-[var(--ok)]'}`}
          >
            {inr(outstanding)}
          </div>
        </div>
      </div>

      {outstanding > 0 ? (
        <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-[11px] text-[var(--ink-3)]">
            Charged as {money(summary.amount_to_charge, currency)} at the fixed demo rate of{' '}
            {config?.inr_per_unit ?? '—'} INR per {currency}. Sandbox only: no real money moves.
          </p>
          <Button
            size="sm"
            disabled={!config?.enabled || startPayment.isPending}
            onClick={() => startPayment.mutate()}
            title={config?.enabled ? undefined : 'PayPal is not configured on the server'}
          >
            {startPayment.isPending ? 'Opening PayPal…' : `Pay ${money(summary.amount_to_charge, currency)} with PayPal`}
          </Button>
        </div>
      ) : (
        <p className="mt-4 text-[11px] text-[var(--ok)]">The shortfall has been paid through PayPal.</p>
      )}

      {topups.length > 0 && (
        <div className="mt-3 divide-y divide-[var(--line)] border-t border-[var(--line)]">
          {topups.slice(0, 3).map((p) => (
            <div key={p.id} className="flex items-center justify-between py-2 text-[11px]">
              <span className="text-[var(--ink-3)]">
                {formatDateTime(p.updated_at)} · capture <span className="font-mono">{p.paypal_capture_id}</span>
              </span>
              <span className="font-mono font-medium">
                {inr(p.amount_inr)} ({money(p.amount_charged, p.currency)})
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
