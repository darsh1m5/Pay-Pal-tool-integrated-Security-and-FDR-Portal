import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Banknote } from 'lucide-react';
import { toast } from 'sonner';
import { ApiError, api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { formatDateTime, inr } from '@/lib/format';
import { Button } from '@/components/ui/button';
import type { PaymentItem, PaypalConfig } from '@/lib/types';

const money = (value: number, currency: string) =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(value);

interface Props {
  fdrId: number;
  fdrNumber: string;
  status: string;
}

/**
 * Release refund through PayPal Payouts (sandbox). Visible on released deposits; only the
 * Competent Authority can send it, and a deposit can be refunded once.
 */
export function PaypalRefundCard({ fdrId, fdrNumber, status }: Props) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [email, setEmail] = useState('');

  const { data: config } = useQuery<PaypalConfig>({
    queryKey: ['payments', 'config'],
    queryFn: () => api.get<PaypalConfig>('/payments/config'),
  });
  const { data: payments } = useQuery<PaymentItem[]>({
    queryKey: ['payments', 'fdr', fdrId],
    queryFn: () => api.get<PaymentItem[]>(`/payments?fdr_id=${fdrId}`),
  });

  const refund = useMutation({
    mutationFn: () => api.post<PaymentItem>(`/payments/refund/${fdrId}`, { receiver_email: email.trim() }),
    onSuccess: () => {
      toast.success('Refund sent through PayPal (sandbox)');
      queryClient.invalidateQueries({ queryKey: ['payments'] });
      queryClient.invalidateQueries({ queryKey: ['fdrs'] });
      queryClient.invalidateQueries({ queryKey: ['audit'] });
    },
    onError: (err) => {
      toast.error(err instanceof ApiError ? err.detail : 'Refund failed');
      queryClient.invalidateQueries({ queryKey: ['payments'] });
    },
  });

  const refunds = (payments ?? []).filter((p) => p.kind === 'release_refund');
  const done = refunds.find((p) => p.status === 'completed');
  if (status !== 'released' && refunds.length === 0) return null;

  const canSend = user?.role === 'approver' && status === 'released' && !done;
  const emailOk = /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.trim());

  return (
    <div className="rounded-[6px] border border-[var(--line)] bg-[var(--surface-2)] p-4 space-y-3" data-testid="paypal-refund-card">
      <div className="flex items-center justify-between pb-2 border-b border-[var(--line)]">
        <div className="flex items-center gap-2">
          <Banknote className="h-4 w-4 text-[var(--ink-2)]" />
          <h3 className="text-xs font-semibold text-[var(--ink)]">Refund via PayPal</h3>
        </div>
        <span className="rounded-full bg-[var(--info-bg)] px-2 py-0.5 text-[10px] font-medium text-[var(--info)]">
          PayPal sandbox
        </span>
      </div>

      {done ? (
        <div className="space-y-1 text-xs">
          <div className="font-medium text-[var(--ok)]">
            Refund sent: {inr(done.amount_inr)} ({money(done.amount_charged, done.currency)})
          </div>
          <div className="text-[11px] text-[var(--ink-3)]">
            Payout batch <span className="font-mono">{done.paypal_payout_batch_id}</span> · status{' '}
            {done.provider_status} · to {done.receiver_email} · {formatDateTime(done.updated_at)}
          </div>
        </div>
      ) : canSend ? (
        <div className="space-y-2">
          <p className="text-[11px] text-[var(--ink-3)]">
            The release for FDR {fdrNumber} is sanctioned. Send the refund to the institution&apos;s PayPal account.
            The amount is taken from the register; sandbox only, no real money moves.
          </p>
          <div className="flex flex-col gap-2 sm:flex-row">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Institution's PayPal sandbox email"
              className="h-8 flex-1 rounded-[6px] border border-[var(--line)] bg-white px-2 text-xs"
              aria-label="PayPal receiver email"
            />
            <Button
              size="sm"
              disabled={!config?.enabled || !emailOk || refund.isPending}
              onClick={() => refund.mutate()}
              title={config?.enabled ? undefined : 'PayPal is not configured on the server'}
            >
              {refund.isPending ? 'Sending…' : 'Send refund'}
            </Button>
          </div>
        </div>
      ) : (
        <p className="text-[11px] text-[var(--ink-3)]">
          {user?.role === 'approver'
            ? 'No refund has been sent for this deposit.'
            : 'The Competent Authority sends the refund once a release is sanctioned.'}
        </p>
      )}

      {refunds.some((p) => p.status === 'failed') && !done && (
        <p className="text-[11px] text-[var(--risk)]">
          Last attempt failed: {refunds.find((p) => p.status === 'failed')?.failure_reason}
        </p>
      )}
    </div>
  );
}
