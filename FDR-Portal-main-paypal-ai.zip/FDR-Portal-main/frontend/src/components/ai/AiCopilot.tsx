import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import { ApiError, api } from '@/lib/api';
import { Button } from '@/components/ui/button';
import type { AiConfig, AiDraft } from '@/lib/types';

interface Props {
  fdrId: number;
  mode: 'observation' | 'explain';
  /** observation mode: receives the draft so the reviewer can edit it in the normal form */
  onDraft?: (text: string) => void;
}

/**
 * Deposit Copilot button. The AI only drafts text from the deposit's rule findings; a person reads it,
 * edits it and takes every action through the normal, role-checked buttons.
 */
export function AiCopilot({ fdrId, mode, onDraft }: Props) {
  const queryClient = useQueryClient();
  const [explanation, setExplanation] = useState<AiDraft | null>(null);

  const { data: config } = useQuery<AiConfig>({
    queryKey: ['ai', 'config'],
    queryFn: () => api.get<AiConfig>('/ai/config'),
  });

  const draft = useMutation({
    mutationFn: () => api.post<AiDraft>(`/ai/fdrs/${fdrId}/draft`, { mode }),
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['audit'] });
      if (mode === 'observation') {
        onDraft?.(result.text);
        toast.success(
          result.used_ai ? 'AI draft added below. Review and edit it before raising.' : result.text,
        );
      } else {
        setExplanation(result);
      }
    },
    onError: (err) => toast.error(err instanceof ApiError ? err.detail : 'Could not generate a draft'),
  });

  const label = mode === 'observation' ? 'Draft with AI' : 'Explain with AI';

  return (
    <div className="space-y-2" data-testid={`ai-copilot-${mode}`}>
      <div className="flex items-center gap-2">
        <Button
          type="button"
          size="sm"
          variant="outline"
          className="gap-1.5 text-xs"
          disabled={!config?.enabled || draft.isPending}
          onClick={() => draft.mutate()}
          title={config?.enabled ? undefined : 'The AI Copilot is not configured on the server'}
        >
          <Sparkles className="h-3.5 w-3.5 text-[var(--violet)]" />
          {draft.isPending ? 'Thinking…' : label}
        </Button>
        <span className="text-[10px] text-[var(--ink-3)]">Drafts only. A person decides and acts.</span>
      </div>

      {mode === 'explain' && explanation && (
        <div className="rounded-[6px] border border-[var(--line)] bg-[var(--violet-bg)] p-3">
          <div className="mb-1 flex items-center justify-between text-[10px] font-medium text-[var(--violet)]">
            <span>{explanation.used_ai ? 'AI-generated explanation' : 'Result'}</span>
            {explanation.used_ai && explanation.model && <span className="font-mono">{explanation.model}</span>}
          </div>
          <p className="whitespace-pre-line text-xs text-[var(--ink)]">{explanation.text}</p>
          {explanation.used_ai && (
            <p className="mt-2 text-[10px] text-[var(--ink-3)]">
              Generated from the rules-engine findings above. Check it against the findings before acting.
            </p>
          )}
        </div>
      )}
    </div>
  );
}
