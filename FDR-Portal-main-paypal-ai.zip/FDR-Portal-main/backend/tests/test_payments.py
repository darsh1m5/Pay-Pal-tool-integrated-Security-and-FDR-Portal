"""PayPal sandbox payments: shortfall top-up, release refund, scoping, failures and audit.

PayPal itself is replaced by an `httpx.MockTransport`, so these tests never touch the network and
need no credentials. They check what Amanat sends to PayPal and what it records afterwards.
"""

import json
from dataclasses import replace
from datetime import date, timedelta
from decimal import Decimal

import httpx
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import config, paypal
from app.audit import verify_chain
from app.db import SessionLocal
from app.models import (
    AuditLog,
    Fdr,
    FdrStatus,
    Institution,
    PaymentKind,
    PaymentStatus,
    PaypalTransaction,
    Purpose,
    User,
)
from app.rules import RuleContext

SECRET = "test-secret-value"
CLIENT_ID = "test-client-id"


class FakePayPal:
    """Records every request and answers like the PayPal sandbox would."""

    def __init__(self) -> None:
        self.requests: list[tuple[str, str, dict]] = []
        self.fail_payout = False
        self.order_counter = 0

    def __call__(self, request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content) if request.content and request.headers.get(
            "content-type", ""
        ).startswith("application/json") else {}
        path = request.url.path
        self.requests.append((request.method, path, body))
        if path == "/v1/oauth2/token":
            return httpx.Response(200, json={"access_token": "sandbox-token"})
        if path == "/v2/checkout/orders":
            self.order_counter += 1
            order_id = f"ORDER-{self.order_counter}"
            return httpx.Response(
                201,
                json={
                    "id": order_id,
                    "status": "PAYER_ACTION_REQUIRED",
                    "links": [{"rel": "payer-action", "href": f"https://www.sandbox.paypal.com/checkoutnow?token={order_id}"}],
                },
            )
        if path.startswith("/v2/checkout/orders/") and path.endswith("/capture"):
            return httpx.Response(
                201,
                json={
                    "status": "COMPLETED",
                    "payer": {"email_address": "buyer@example.com"},
                    "purchase_units": [{"payments": {"captures": [{"id": "CAPTURE-1", "status": "COMPLETED"}]}}],
                },
            )
        if path == "/v1/payments/payouts":
            if self.fail_payout:
                return httpx.Response(400, json={"name": "VALIDATION_ERROR", "message": "Receiver is not valid"})
            return httpx.Response(201, json={"batch_header": {"payout_batch_id": "BATCH-1", "batch_status": "PENDING"}})
        return httpx.Response(404, json={"message": "unexpected call"})


@pytest.fixture()
def fake_paypal(monkeypatch: pytest.MonkeyPatch) -> FakePayPal:
    fake = FakePayPal()
    monkeypatch.setattr(paypal, "_transport", httpx.MockTransport(fake))
    monkeypatch.setattr(
        config,
        "settings",
        replace(
            config.settings,
            paypal_client_id=CLIENT_ID,
            paypal_client_secret=SECRET,
            paypal_currency="USD",
            paypal_inr_per_unit=83.0,
            app_base_url="http://localhost:5173",
        ),
    )
    return fake


def _institution_of(email: str) -> int:
    with SessionLocal() as db:
        user = db.scalar(select(User).where(User.email == email))
        assert user is not None and user.institution_id is not None
        return user.institution_id


def _make_released_fdr(number: str, maturity_amount: str = "830000.00") -> int:
    with SessionLocal() as db:
        inst = db.query(Institution).first()
        assert inst is not None
        fdr = Fdr(
            institution_id=inst.id,
            fdr_number=number,
            bank_name="State Bank of India",
            branch="Main Branch",
            ifsc="SBIN0001234",
            amount=Decimal("800000.00"),
            issue_date=date.today() - timedelta(days=500),
            maturity_date=date.today() - timedelta(days=30),
            interest_rate=Decimal("7.00"),
            maturity_amount=Decimal(maturity_amount),
            purpose=Purpose.security_deposit,
            lien_to_aicte=True,
            status=FdrStatus.released,
        )
        db.add(fdr)
        db.commit()
        db.refresh(fdr)
        return fdr.id


def _audit_actions(fdr_id: int | None = None) -> list[str]:
    with SessionLocal() as db:
        stmt = select(AuditLog.action).order_by(AuditLog.id)
        if fdr_id is not None:
            stmt = stmt.where(AuditLog.fdr_id == fdr_id)
        return list(db.scalars(stmt))


def test_config_reports_state_but_never_credentials(
    client: TestClient, admin: dict[str, str], fake_paypal: FakePayPal
) -> None:
    resp = client.get("/api/payments/config", headers=admin)
    assert resp.status_code == 200
    assert resp.json()["enabled"] is True
    assert resp.json()["environment"] == "sandbox"
    assert SECRET not in resp.text and CLIENT_ID not in resp.text


def test_everything_is_disabled_without_credentials(
    client: TestClient, approver: dict[str, str], monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(config, "settings", replace(config.settings, paypal_client_id="", paypal_client_secret=""))
    assert client.get("/api/payments/config", headers=approver).json()["enabled"] is False
    resp = client.post("/api/payments/refund/1", json={"receiver_email": "a@b.co"}, headers=approver)
    assert resp.status_code == 503
    assert "not configured" in resp.json()["detail"].lower()


def test_payments_require_login(client: TestClient) -> None:
    assert client.get("/api/payments").status_code == 401
    assert client.get("/api/payments/config").status_code == 401


def test_shortfall_payment_flow(
    client: TestClient,
    institution_deccan: dict[str, str],
    institution_kaveri: dict[str, str],
    fake_paypal: FakePayPal,
) -> None:
    inst_id = _institution_of("deccan.crest@fdrportal.demo")
    with SessionLocal() as db:
        inst = db.get(Institution, inst_id)
        original = inst.required_deposit
        held = RuleContext.load(db).held_by_institution.get(inst_id, 0.0)
        inst.required_deposit = Decimal(str(held)) + Decimal("830000.00")  # shortfall = Rs 8,30,000
        db.commit()
    try:
        summary = client.get("/api/payments/shortfall", headers=institution_deccan).json()
        assert summary["shortfall"] == 830000.0
        assert summary["outstanding_inr"] == 830000.0
        assert summary["amount_to_charge"] == 10000.0  # 830000 / 83

        # The browser never sends an amount: a body full of fake prices changes nothing.
        order = client.post(
            "/api/payments/shortfall/order",
            json={"institution_id": 999999, "amount": 1},
            headers=institution_deccan,
        )
        assert order.status_code == 201, order.text
        data = order.json()
        assert data["approve_url"].startswith("https://www.sandbox.paypal.com/")
        sent = next(body for _m, path, body in fake_paypal.requests if path == "/v2/checkout/orders")
        assert sent["purchase_units"][0]["amount"] == {"currency_code": "USD", "value": "10000.00"}
        assert sent["payment_source"]["paypal"]["experience_context"]["return_url"].endswith("/payments/return")

        # Another institution cannot capture this order, and cannot tell it exists.
        other = client.post(
            "/api/payments/shortfall/capture", json={"order_id": data["order_id"]}, headers=institution_kaveri
        )
        assert other.status_code == 404

        captured = client.post(
            "/api/payments/shortfall/capture", json={"order_id": data["order_id"]}, headers=institution_deccan
        )
        assert captured.status_code == 200, captured.text
        item = captured.json()
        assert item["status"] == "completed"
        assert item["paypal_capture_id"] == "CAPTURE-1"
        assert item["amount_inr"] == 830000.0

        # Capturing twice is safe and does not call PayPal again.
        calls_before = len(fake_paypal.requests)
        again = client.post(
            "/api/payments/shortfall/capture", json={"order_id": data["order_id"]}, headers=institution_deccan
        )
        assert again.status_code == 200
        assert len(fake_paypal.requests) == calls_before

        after = client.get("/api/payments/shortfall", headers=institution_deccan).json()
        assert after["outstanding_inr"] == 0.0
        assert client.post(
            "/api/payments/shortfall/order", json={}, headers=institution_deccan
        ).status_code == 409

        actions = _audit_actions()
        assert "payment.order_created" in actions and "payment.captured" in actions
        with SessionLocal() as db:
            assert verify_chain(db).intact
    finally:
        with SessionLocal() as db:
            db.get(Institution, inst_id).required_deposit = original
            db.commit()


def test_refund_flow_and_permissions(
    client: TestClient,
    admin: dict[str, str],
    reviewer: dict[str, str],
    approver: dict[str, str],
    auditor: dict[str, str],
    institution_deccan: dict[str, str],
    fake_paypal: FakePayPal,
) -> None:
    fdr_id = _make_released_fdr("TEST-PAYPAL-REF-001")
    body = {"receiver_email": "institution@example.com"}

    # Only the Competent Authority can send a refund.
    for headers in (admin, reviewer, auditor, institution_deccan):
        assert client.post(f"/api/payments/refund/{fdr_id}", json=body, headers=headers).status_code == 403

    assert client.post(
        f"/api/payments/refund/{fdr_id}", json={"receiver_email": "not-an-email"}, headers=approver
    ).status_code == 422

    with SessionLocal() as db:
        unreleased = db.scalar(select(Fdr.id).where(Fdr.status != FdrStatus.released))
    assert client.post(f"/api/payments/refund/{unreleased}", json=body, headers=approver).status_code == 409

    resp = client.post(f"/api/payments/refund/{fdr_id}", json=body, headers=approver)
    assert resp.status_code == 201, resp.text
    item = resp.json()
    assert item["kind"] == "release_refund"
    assert item["status"] == "completed"
    assert item["paypal_payout_batch_id"] == "BATCH-1"
    assert item["amount_inr"] == 830000.0
    assert item["amount_charged"] == 10000.0

    payout = next(b for _m, path, b in fake_paypal.requests if path == "/v1/payments/payouts")
    assert payout["sender_batch_header"]["sender_batch_id"] == f"amanat-refund-fdr{fdr_id}"
    assert payout["items"][0]["receiver"] == "institution@example.com"
    assert payout["items"][0]["amount"] == {"value": "10000.00", "currency": "USD"}

    # A deposit is refunded once.
    assert client.post(f"/api/payments/refund/{fdr_id}", json=body, headers=approver).status_code == 409

    assert "payment.refund_sent" in _audit_actions(fdr_id)
    listed = client.get(f"/api/payments?fdr_id={fdr_id}", headers=auditor).json()
    assert [p["id"] for p in listed] == [item["id"]]
    with SessionLocal() as db:
        assert verify_chain(db).intact


def test_failed_refund_is_recorded_and_can_be_retried(
    client: TestClient, approver: dict[str, str], fake_paypal: FakePayPal
) -> None:
    fdr_id = _make_released_fdr("TEST-PAYPAL-REF-002")
    body = {"receiver_email": "institution@example.com"}

    fake_paypal.fail_payout = True
    failed = client.post(f"/api/payments/refund/{fdr_id}", json=body, headers=approver)
    assert failed.status_code == 502
    assert "Receiver is not valid" in failed.json()["detail"]
    assert SECRET not in failed.text

    with SessionLocal() as db:
        tx = db.scalar(select(PaypalTransaction).where(PaypalTransaction.fdr_id == fdr_id))
        assert tx is not None and tx.status == PaymentStatus.failed
        assert tx.kind == PaymentKind.release_refund
    assert "payment.refund_failed" in _audit_actions(fdr_id)

    fake_paypal.fail_payout = False
    retry = client.post(f"/api/payments/refund/{fdr_id}", json=body, headers=approver)
    assert retry.status_code == 201
    assert retry.json()["status"] == "completed"


def test_bad_credentials_give_a_clear_error(
    client: TestClient, approver: dict[str, str], monkeypatch: pytest.MonkeyPatch
) -> None:
    def reject(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"error": "invalid_client"})

    monkeypatch.setattr(paypal, "_transport", httpx.MockTransport(reject))
    monkeypatch.setattr(
        config, "settings", replace(config.settings, paypal_client_id="x", paypal_client_secret=SECRET)
    )
    fdr_id = _make_released_fdr("TEST-PAYPAL-REF-003")
    resp = client.post(
        f"/api/payments/refund/{fdr_id}", json={"receiver_email": "institution@example.com"}, headers=approver
    )
    assert resp.status_code == 502
    assert "credentials" in resp.json()["detail"].lower()
    assert SECRET not in resp.text


def test_institution_only_sees_its_own_payments(
    client: TestClient,
    institution_deccan: dict[str, str],
    institution_kaveri: dict[str, str],
    admin: dict[str, str],
) -> None:
    deccan = _institution_of("deccan.crest@fdrportal.demo")
    kaveri = _institution_of("kaveri.delta@fdrportal.demo")
    assert deccan != kaveri
    for item in client.get("/api/payments", headers=institution_kaveri).json():
        assert item["institution_id"] == kaveri
    for item in client.get("/api/payments", headers=institution_deccan).json():
        assert item["institution_id"] == deccan
    assert client.get("/api/payments", headers=admin).status_code == 200
