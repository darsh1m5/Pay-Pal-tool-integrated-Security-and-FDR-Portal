"""Deposit Copilot: AI-drafted text for officers. Drafts only; a person reviews and acts on every one.

Two modes, both built from the deposit's rule-engine findings (never free text typed by users):
  * observation: a reviewer's scrutiny query to the institution, to be edited and raised by the reviewer.
  * explain: a plain-language explanation of the findings and how to fix them, for any role that can see the deposit.
"""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app import ai, config
from app.audit import write_audit
from app.db import get_db
from app.models import AuditEntity, Role
from app.routers.fdrs import load_fdr
from app.schemas import AiConfigOut, AiDraftIn, AiDraftOut, FdrDetail
from app.security import CurrentUser
from app.serializers import fdr_detail

router = APIRouter(prefix="/ai", tags=["ai"])

Db = Annotated[Session, Depends(get_db)]

MAX_FINDINGS = 12

INSTRUCTIONS = {
    "observation": (
        "Write ONE scrutiny observation of two to four sentences that a reviewer can send to the institution. "
        "Mention the FDR number, ask for exactly the clarification or documents needed to resolve the findings, "
        "and do not state any decision."
    ),
    "explain": (
        "Explain, for the institution's deposit cell, what each finding means and the exact steps to fix it. "
        "Use a short numbered list in plain text (1., 2., 3.), under 150 words in total."
    ),
}

NO_FINDINGS = {
    "observation": "No discrepancies were found on this deposit, so no observation is needed.",
    "explain": "No discrepancies were found on this deposit. There is nothing to fix.",
}


def _facts(fdr: FdrDetail) -> str:
    """Only register facts and rule findings go to the model: no remarks, emails or uploaded text."""
    lines = [
        f"FDR number: {fdr.fdr_number}",
        f"Bank: {fdr.bank_name}",
        f"Amount: Rs {fdr.amount:,.2f}",
        f"Issue date: {fdr.issue_date.isoformat()}",
        f"Maturity date: {fdr.maturity_date.isoformat()} ({fdr.days_to_maturity} days from today)",
        f"Interest rate: {fdr.interest_rate}%",
        f"Status: {fdr.status.value}",
        f"Verification: {fdr.verification.value}",
        f"Lien in favour of the bureau: {'yes' if fdr.lien_to_aicte else 'no'}",
        f"Documents attached: {fdr.document_count}",
        "Findings from the rules engine:",
    ]
    for item in fdr.findings[:MAX_FINDINGS]:
        lines.append(f"- [{item.severity.value}] {item.message} Suggested fix: {item.fix}")
    return "\n".join(lines)


@router.get("/config", response_model=AiConfigOut)
def ai_config(user: CurrentUser) -> AiConfigOut:
    return AiConfigOut(enabled=ai.is_configured(), model=config.settings.anthropic_model)


@router.post("/fdrs/{fdr_id}/draft", response_model=AiDraftOut)
def draft(fdr_id: int, body: AiDraftIn, db: Db, user: CurrentUser) -> AiDraftOut:
    if body.mode == "observation" and user.role != Role.reviewer:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Only a Reviewer can draft an observation")
    detail = fdr_detail(db, load_fdr(db, fdr_id, user), user)
    considered = min(len(detail.findings), MAX_FINDINGS)
    if considered == 0:
        # Nothing to draft from, so do not spend an AI call or let the model invent a problem.
        return AiDraftOut(mode=body.mode, text=NO_FINDINGS[body.mode], used_ai=False, model=None, findings_considered=0)

    ai.require_configured()
    prompt = f"{INSTRUCTIONS[body.mode]}\n\n<deposit_data>\n{_facts(detail)}\n</deposit_data>"
    text = ai.complete(prompt)
    write_audit(
        db,
        actor=user,
        action="ai.draft_generated",
        entity=AuditEntity.fdr,
        entity_id=detail.id,
        fdr_id=detail.id,
        detail={"mode": body.mode, "model": config.settings.anthropic_model, "findings": considered},
    )
    db.commit()
    return AiDraftOut(
        mode=body.mode, text=text, used_ai=True, model=config.settings.anthropic_model, findings_considered=considered
    )
