"""PayPal sandbox payments: institutions pay a deposit shortfall, the bureau refunds a released deposit.

Every movement is stored in `paypal_transactions` and written to the hash-chained audit log, so a
payment is as provable as any other action in the portal. Amounts are always computed on the server
from the register; the browser never supplies a price.
"""

from decimal import Decimal
from typing import Annotated
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from app import config, paypal
from app.audit import write_audit
from app.db import get_db
from app.models import (
    AuditEntity,
    Fdr,
    FdrStatus,
    Institution,
    PaymentKind,
    PaymentStatus,
    PaypalTransaction,
    Role,
    User,
)
from app.routers.fdrs import load_fdr
from app.rules import RuleContext, fdr_projected_value
from app.schemas import (
    PaymentCaptureIn,
    PaymentItem,
    PaymentOrderOut,
    PaypalConfigOut,
    RefundIn,
    ShortfallOrderIn,
    ShortfallSummary,
)
from app.security import AdminOrInstitutionUser, ApproverUser, CurrentUser

router = APIRouter(prefix="/payments", tags=["payments"])

Db = Annotated[Session, Depends(get_db)]


def _serialize(tx: PaypalTransaction) -> PaymentItem:
    return PaymentItem(
        id=tx.id,
        kind=tx.kind,
        status=tx.status,
        institution_id=tx.institution_id,
        institution_name=tx.institution.name if tx.institution else "",
        fdr_id=tx.fdr_id,
        fdr_number=tx.fdr.fdr_number if tx.fdr else None,
        amount_inr=float(tx.amount_inr),
        currency=tx.currency,
        amount_charged=float(tx.amount_charged),
        fx_rate=float(tx.fx_rate),
        paypal_order_id=tx.paypal_order_id,
        paypal_capture_id=tx.paypal_capture_id,
        paypal_payout_batch_id=tx.paypal_payout_batch_id,
        provider_status=tx.provider_status,
        receiver_email=tx.receiver_email,
        payer_email=tx.payer_email,
        failure_reason=tx.failure_reason,
        created_by=tx.created_by.name if tx.created_by else None,
        created_at=tx.created_at,
        updated_at=tx.updated_at,
    )


def _load_tx(db: Session, tx_id: int) -> PaypalTransaction:
    tx = db.scalar(
        select(PaypalTransaction)
        .options(
            selectinload(PaypalTransaction.institution),
            selectinload(PaypalTransaction.fdr),
            selectinload(PaypalTransaction.created_by),
        )
        .where(PaypalTransaction.id == tx_id)
    )
    if tx is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Payment not found")
    return tx


def _scoped_institution(db: Session, user: User, institution_id: int | None) -> Institution:
    """Institutions are locked to their own record; bureau users must name one."""
    target = user.institution_id if user.role == Role.institution else institution_id
    if target is None:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="institution_id is required")
    inst = db.get(Institution, target)
    if inst is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Institution not found")
    return inst


def _summary(db: Session, inst: Institution) -> ShortfallSummary:
    ctx = RuleContext.load(db)
    shortfall = ctx.shortfall(inst.id)
    paid = db.scalar(
        select(func.coalesce(func.sum(PaypalTransaction.amount_inr), 0)).where(
            PaypalTransaction.institution_id == inst.id,
            PaypalTransaction.kind == PaymentKind.shortfall_topup,
            PaypalTransaction.status == PaymentStatus.completed,
        )
    )
    paid_inr = float(paid or 0)
    outstanding = max(0.0, round(shortfall - paid_inr, 2))
    charge, _rate = paypal.inr_to_charge(outstanding) if outstanding > 0 else (Decimal("0"), Decimal("0"))
    return ShortfallSummary(
        institution_id=inst.id,
        required_deposit=float(inst.required_deposit),
        held=float(ctx.held_by_institution.get(inst.id, 0.0)),
        shortfall=shortfall,
        paid_via_paypal_inr=paid_inr,
        outstanding_inr=outstanding,
        currency=config.settings.paypal_currency,
        amount_to_charge=float(charge),
    )


@router.get("/config", response_model=PaypalConfigOut)
def paypal_config(user: CurrentUser) -> PaypalConfigOut:
    # Never returns credentials: only whether PayPal is switched on and how amounts are converted.
    return PaypalConfigOut(
        enabled=paypal.is_configured(),
        currency=config.settings.paypal_currency,
        inr_per_unit=config.settings.paypal_inr_per_unit,
    )


@router.get("/shortfall", response_model=ShortfallSummary)
def shortfall_summary(db: Db, user: CurrentUser, institution_id: int | None = None) -> ShortfallSummary:
    return _summary(db, _scoped_institution(db, user, institution_id))


@router.post("/shortfall/order", response_model=PaymentOrderOut, status_code=status.HTTP_201_CREATED)
def create_shortfall_order(body: ShortfallOrderIn, db: Db, user: AdminOrInstitutionUser) -> PaymentOrderOut:
    paypal.require_configured()
    inst = _scoped_institution(db, user, body.institution_id)
    summary = _summary(db, inst)
    if summary.outstanding_inr <= 0:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="No shortfall is outstanding for this institution")

    charge, rate = paypal.inr_to_charge(summary.outstanding_inr)
    reference = f"AMN-SF-{inst.id}-{uuid4().hex[:10].upper()}"
    # The PayPal call happens before any database write so no transaction or audit lock is held during it.
    order_id, approve_url = paypal.create_order(
        amount=charge,
        currency=config.settings.paypal_currency,
        reference=reference,
        description=f"Security deposit top-up for {inst.name} ({inst.aicte_id})",
        return_url=f"{config.settings.app_base_url}/payments/return",
        cancel_url=f"{config.settings.app_base_url}/?paypal=cancelled",
        request_id=reference,
    )
    tx = PaypalTransaction(
        kind=PaymentKind.shortfall_topup,
        status=PaymentStatus.created,
        institution_id=inst.id,
        amount_inr=Decimal(str(summary.outstanding_inr)),
        currency=config.settings.paypal_currency,
        amount_charged=charge,
        fx_rate=rate,
        paypal_order_id=order_id,
        provider_status="CREATED",
        created_by_id=user.id,
    )
    db.add(tx)
    db.flush()
    write_audit(
        db,
        actor=user,
        action="payment.order_created",
        entity=AuditEntity.payment,
        entity_id=tx.id,
        detail={
            "kind": tx.kind.value,
            "institution_id": inst.id,
            "amount_inr": summary.outstanding_inr,
            "amount_charged": float(charge),
            "currency": tx.currency,
            "paypal_order_id": order_id,
        },
    )
    db.commit()
    return PaymentOrderOut(transaction_id=tx.id, order_id=order_id, approve_url=approve_url)


@router.post("/shortfall/capture", response_model=PaymentItem)
def capture_shortfall(body: PaymentCaptureIn, db: Db, user: AdminOrInstitutionUser) -> PaymentItem:
    paypal.require_configured()
    tx = db.scalar(
        select(PaypalTransaction).where(
            PaypalTransaction.paypal_order_id == body.order_id,
            PaypalTransaction.kind == PaymentKind.shortfall_topup,
        )
    )
    # Same answer for "unknown" and "someone else's" so order ids cannot be probed.
    if tx is None or (user.role == Role.institution and tx.institution_id != user.institution_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Payment not found")
    if tx.status == PaymentStatus.completed:
        return _serialize(_load_tx(db, tx.id))  # already captured: safe to call again

    result = paypal.capture_order(body.order_id, request_id=f"capture-{tx.paypal_order_id}")
    if result["status"] != "COMPLETED" or (result["capture_status"] and result["capture_status"] != "COMPLETED"):
        tx.status = PaymentStatus.failed
        tx.provider_status = (result["capture_status"] or result["status"] or "UNKNOWN")[:40]
        tx.failure_reason = "PayPal did not complete the payment"
        db.commit()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="PayPal did not complete the payment")

    tx.status = PaymentStatus.completed
    tx.paypal_capture_id = result["capture_id"]
    tx.payer_email = result["payer_email"]
    tx.provider_status = "COMPLETED"
    write_audit(
        db,
        actor=user,
        action="payment.captured",
        entity=AuditEntity.payment,
        entity_id=tx.id,
        detail={
            "kind": tx.kind.value,
            "institution_id": tx.institution_id,
            "amount_inr": float(tx.amount_inr),
            "amount_charged": float(tx.amount_charged),
            "currency": tx.currency,
            "paypal_order_id": tx.paypal_order_id,
            "paypal_capture_id": tx.paypal_capture_id,
        },
    )
    db.commit()
    return _serialize(_load_tx(db, tx.id))


@router.post("/refund/{fdr_id}", response_model=PaymentItem, status_code=status.HTTP_201_CREATED)
def refund_release(fdr_id: int, body: RefundIn, db: Db, user: ApproverUser) -> PaymentItem:
    """Competent Authority sends the refund for a deposit that has already been sanctioned for release."""
    paypal.require_configured()
    fdr: Fdr = load_fdr(db, fdr_id, user)
    if fdr.status != FdrStatus.released:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Only a released deposit can be refunded. Sanction the release first.",
        )
    existing = db.scalar(
        select(PaypalTransaction).where(
            PaypalTransaction.kind == PaymentKind.release_refund,
            PaypalTransaction.fdr_id == fdr.id,
            PaypalTransaction.status.in_([PaymentStatus.created, PaymentStatus.completed]),
        )
    )
    if existing is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="This deposit has already been refunded")

    amount_inr = float(fdr.maturity_amount) if fdr.maturity_amount is not None else fdr_projected_value(fdr)
    charge, rate = paypal.inr_to_charge(amount_inr)
    tx = PaypalTransaction(
        kind=PaymentKind.release_refund,
        status=PaymentStatus.created,
        institution_id=fdr.institution_id,
        fdr_id=fdr.id,
        amount_inr=Decimal(str(amount_inr)),
        currency=config.settings.paypal_currency,
        amount_charged=charge,
        fx_rate=rate,
        receiver_email=body.receiver_email,
        created_by_id=user.id,
    )
    # One stable batch id per deposit: PayPal itself refuses a second payout with the same id,
    # so a retry after a timeout can never pay the same deposit twice.
    try:
        result = paypal.create_payout(
            batch_id=f"amanat-refund-fdr{fdr.id}",
            item_id=f"fdr-{fdr.id}",
            receiver_email=body.receiver_email,
            amount=charge,
            currency=config.settings.paypal_currency,
            note=f"Refund of security deposit FDR {fdr.fdr_number} ({fdr.institution.name})",
        )
    except HTTPException as exc:
        tx.status = PaymentStatus.failed
        tx.failure_reason = str(exc.detail)[:300]
        db.add(tx)
        db.flush()
        write_audit(
            db,
            actor=user,
            action="payment.refund_failed",
            entity=AuditEntity.payment,
            entity_id=tx.id,
            fdr_id=fdr.id,
            detail={"kind": tx.kind.value, "amount_inr": amount_inr, "reason": tx.failure_reason},
        )
        db.commit()
        raise

    tx.status = PaymentStatus.completed
    tx.paypal_payout_batch_id = result["payout_batch_id"]
    tx.provider_status = result["batch_status"][:40]
    db.add(tx)
    db.flush()
    write_audit(
        db,
        actor=user,
        action="payment.refund_sent",
        entity=AuditEntity.payment,
        entity_id=tx.id,
        fdr_id=fdr.id,
        detail={
            "kind": tx.kind.value,
            "institution_id": fdr.institution_id,
            "amount_inr": amount_inr,
            "amount_charged": float(charge),
            "currency": tx.currency,
            "paypal_payout_batch_id": tx.paypal_payout_batch_id,
            "batch_status": tx.provider_status,
        },
    )
    db.commit()
    return _serialize(_load_tx(db, tx.id))


@router.get("", response_model=list[PaymentItem])
def list_payments(
    db: Db,
    user: CurrentUser,
    fdr_id: int | None = None,
    institution_id: int | None = None,
) -> list[PaymentItem]:
    stmt = (
        select(PaypalTransaction)
        .options(
            selectinload(PaypalTransaction.institution),
            selectinload(PaypalTransaction.fdr),
            selectinload(PaypalTransaction.created_by),
        )
        .order_by(PaypalTransaction.id.desc())
    )
    if user.role == Role.institution:
        stmt = stmt.where(PaypalTransaction.institution_id == user.institution_id)
    elif institution_id is not None:
        stmt = stmt.where(PaypalTransaction.institution_id == institution_id)
    if fdr_id is not None:
        stmt = stmt.where(PaypalTransaction.fdr_id == fdr_id)
    return [_serialize(tx) for tx in db.scalars(stmt).all()]
