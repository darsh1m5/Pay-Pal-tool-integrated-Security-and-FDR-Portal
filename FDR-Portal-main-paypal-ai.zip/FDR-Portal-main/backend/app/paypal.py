"""Minimal PayPal REST client, sandbox only.

Two flows use it:
  * Orders v2 (Checkout): an institution pays a security-deposit shortfall.
  * Payouts: the bureau refunds a released deposit to the institution's PayPal account.

The client only ever talks to the PayPal *sandbox*, so no real money can move. Credentials are
read from the environment (see `.env.example`), are sent only to PayPal, and never appear in
responses, logs or error messages.
"""

from decimal import ROUND_HALF_UP, Decimal
from typing import Any

import httpx
from fastapi import HTTPException, status

from app import config

SANDBOX_BASE_URL = "https://api-m.sandbox.paypal.com"
_TIMEOUT = httpx.Timeout(20.0, connect=10.0)

# Tests replace this with an `httpx.MockTransport`; production leaves it as None.
_transport: httpx.BaseTransport | None = None


def is_configured() -> bool:
    cfg = config.settings
    return bool(cfg.paypal_client_id and cfg.paypal_client_secret)


def require_configured() -> None:
    if not is_configured():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="PayPal is not configured. Add PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET to backend/.env.",
        )


def inr_to_charge(amount_inr: Decimal | float) -> tuple[Decimal, Decimal]:
    """Convert rupees to the sandbox currency at the fixed demo rate. Returns (amount, rate)."""
    rate = Decimal(str(config.settings.paypal_inr_per_unit))
    if rate <= 0:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Invalid PayPal exchange rate")
    value = (Decimal(str(amount_inr)) / rate).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return max(value, Decimal("0.01")), rate


def _money(value: Decimal) -> str:
    return f"{value:.2f}"


def _upstream(message: str) -> HTTPException:
    return HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=message)


def _error_text(response: httpx.Response) -> str:
    try:
        body = response.json()
    except ValueError:
        return f"HTTP {response.status_code}"
    parts = [str(body.get("message") or body.get("error_description") or body.get("name") or "")]
    for item in (body.get("details") or [])[:2]:
        issue = item.get("description") or item.get("issue")
        if issue:
            parts.append(str(issue))
    text = " - ".join(p for p in parts if p) or f"HTTP {response.status_code}"
    return text[:240]


def _request(method: str, path: str, *, json: dict[str, Any] | None = None, request_id: str | None = None) -> dict[str, Any]:
    require_configured()
    cfg = config.settings
    try:
        with httpx.Client(base_url=SANDBOX_BASE_URL, timeout=_TIMEOUT, transport=_transport) as client:
            token_resp = client.post(
                "/v1/oauth2/token",
                auth=(cfg.paypal_client_id, cfg.paypal_client_secret),
                data={"grant_type": "client_credentials"},
            )
            if token_resp.status_code >= 400:
                raise _upstream("PayPal rejected the sandbox credentials. Check PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET.")
            access_token = token_resp.json().get("access_token")
            if not access_token:
                raise _upstream("PayPal did not return an access token")
            headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
            if request_id:
                headers["PayPal-Request-Id"] = request_id  # idempotency key
            response = client.request(method, path, json=json, headers=headers)
    except httpx.HTTPError as exc:
        raise _upstream("Could not reach PayPal. Check the network connection and try again.") from exc
    if response.status_code >= 400:
        raise _upstream(f"PayPal rejected the request: {_error_text(response)}")
    try:
        return response.json()
    except ValueError as exc:
        raise _upstream("PayPal returned an unreadable response") from exc


def create_order(
    *,
    amount: Decimal,
    currency: str,
    reference: str,
    description: str,
    return_url: str,
    cancel_url: str,
    request_id: str,
) -> tuple[str, str]:
    """Create a CAPTURE order. Returns (order_id, url the payer must open to approve it)."""
    data = _request(
        "POST",
        "/v2/checkout/orders",
        request_id=request_id,
        json={
            "intent": "CAPTURE",
            "purchase_units": [
                {
                    "reference_id": reference,
                    "custom_id": reference,
                    "description": description[:127],
                    "amount": {"currency_code": currency, "value": _money(amount)},
                }
            ],
            "payment_source": {
                "paypal": {
                    "experience_context": {
                        "brand_name": "Amanat",
                        "user_action": "PAY_NOW",
                        "shipping_preference": "NO_SHIPPING",
                        "return_url": return_url,
                        "cancel_url": cancel_url,
                    }
                }
            },
        },
    )
    order_id = data.get("id")
    approve = next(
        (link.get("href") for link in data.get("links", []) if link.get("rel") in ("payer-action", "approve")),
        None,
    )
    if not order_id or not approve:
        raise _upstream("PayPal did not return an approval link")
    return str(order_id), str(approve)


def capture_order(order_id: str, *, request_id: str) -> dict[str, Any]:
    """Capture an approved order. Returns a flat summary: status, capture_id, payer_email."""
    data = _request("POST", f"/v2/checkout/orders/{order_id}/capture", request_id=request_id, json={})
    captures = [
        capture
        for unit in data.get("purchase_units", [])
        for capture in unit.get("payments", {}).get("captures", [])
    ]
    capture = captures[0] if captures else {}
    return {
        "status": str(data.get("status", "")),
        "capture_status": str(capture.get("status", "")),
        "capture_id": capture.get("id"),
        "payer_email": (data.get("payer") or {}).get("email_address"),
    }


def create_payout(
    *,
    batch_id: str,
    item_id: str,
    receiver_email: str,
    amount: Decimal,
    currency: str,
    note: str,
) -> dict[str, Any]:
    """Send one payout. `batch_id` doubles as the idempotency key. Returns payout_batch_id and status."""
    data = _request(
        "POST",
        "/v1/payments/payouts",
        request_id=batch_id,
        json={
            "sender_batch_header": {
                "sender_batch_id": batch_id,
                "email_subject": "Security deposit refund from Amanat",
                "email_message": note[:200],
            },
            "items": [
                {
                    "recipient_type": "EMAIL",
                    "receiver": receiver_email,
                    "sender_item_id": item_id,
                    "note": note[:200],
                    "amount": {"value": _money(amount), "currency": currency},
                }
            ],
        },
    )
    header = data.get("batch_header") or {}
    batch = header.get("payout_batch_id")
    if not batch:
        raise _upstream("PayPal did not return a payout batch id")
    return {"payout_batch_id": str(batch), "batch_status": str(header.get("batch_status", "PENDING"))}
